#include "stdafx.h"
HANDLE g_iocp = NULL;
HANDLE g_iocp_client= NULL;
int g_cpu = 0;
int buf_len = 65535;
tcp_fun g_fun = NULL;
tcp_fun_client g_fun_client = NULL;

int closesockets(SOCKET so)
{
	if (INVALID_SOCKET == so)
	{
		return 0;
	}
	struct linger lingerStruct;
	lingerStruct.l_onoff = 1;
	lingerStruct.l_linger = 0;
	setsockopt(so, SOL_SOCKET, SO_LINGER, (char *)&lingerStruct, sizeof(lingerStruct));
	shutdown(so,SD_BOTH);
	return closesocket(so);
}